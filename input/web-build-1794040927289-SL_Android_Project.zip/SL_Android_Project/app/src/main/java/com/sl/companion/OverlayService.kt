package com.sl.companion

import android.app.Service
import android.content.Intent
import android.graphics.Color as AndroidColor
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var root: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var expanded = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showOverlay()
    }

    private fun showOverlay() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 10, 12, 10)
            setBackgroundColor(AndroidColor.rgb(8, 8, 8))
        }
        root = container
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val toggle = Button(this).apply {
            text = "SL"
            setTextColor(AndroidColor.WHITE)
            setBackgroundColor(AndroidColor.rgb(25, 25, 25))
            setOnClickListener { expanded = !expanded; renderExpanded(container) }
        }
        header.addView(toggle)
        container.addView(header)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 18; y = 150 }
        params = lp
        wm.addView(container, lp)
    }

    private fun renderExpanded(container: LinearLayout) {
        while (container.childCount > 1) container.removeViewAt(1)
        if (!expanded) {
            params?.width = WindowManager.LayoutParams.WRAP_CONTENT
            params?.height = WindowManager.LayoutParams.WRAP_CONTENT
            params?.let { wm.updateViewLayout(container, it) }
            return
        }
        params?.width = 850
        params?.height = WindowManager.LayoutParams.WRAP_CONTENT
        params?.let { wm.updateViewLayout(container, it) }

        val close = Button(this).apply {
            text = "CLOSE"
            setTextColor(AndroidColor.WHITE)
            setOnClickListener { stopSelf() }
        }
        container.addView(close)
        val title = TextView(this).apply {
            text = "SL • LOCAL LUA EDITOR"
            setTextColor(AndroidColor.WHITE)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
        }
        container.addView(title)
        val editor = EditText(this).apply {
            setText("print('Hello from SL!')")
            setTextColor(AndroidColor.WHITE)
            setHintTextColor(AndroidColor.LTGRAY)
            setHint("Lua code (runs only inside SL)")
            minLines = 4
            setBackgroundColor(AndroidColor.rgb(24, 24, 24))
        }
        container.addView(editor)
        val execute = Button(this).apply {
            text = "EXECUTE IN LOCAL SANDBOX"
            setTextColor(AndroidColor.WHITE)
            setOnClickListener {
                val result = runLuaSafely(editor.text.toString())
                output.text = result
            }
        }
        container.addView(execute)
        val output = TextView(this).apply {
            text = "Ready"
            setTextColor(AndroidColor.WHITE)
            textSize = 12f
        }
        container.addView(output)
        val note = TextView(this).apply {
            text = "Local Lua only — does not run inside Roblox."
            setTextColor(AndroidColor.LTGRAY)
            textSize = 11f
        }
        container.addView(note)
    }

    override fun onDestroy() {
        root?.let { if (it.isAttachedToWindow) wm.removeView(it) }
        root = null
        super.onDestroy()
    }
}
