package com.sl.companion

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.luaj.vm2.Globals
import org.luaj.vm2.lib.jse.JsePlatform

private val Black = Color(0xFF080808)
private val Panel = Color(0xFF151515)
private val White = Color.White
private val Green = Color(0xFF39FF14)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Black, surface = Panel, onBackground = White,
                onSurface = White, primary = Green, onPrimary = Black
            )) {
                HomeScreen(
                    onOverlay = {
                        if (!Settings.canDrawOverlays(this)) {
                            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:$packageName")))
                        } else {
                            startService(Intent(this, OverlayService::class.java))
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun HomeScreen(onOverlay: () -> Unit) {
    var code by remember { mutableStateOf("print('Hello from SL!')") }
    var output by remember { mutableStateOf("Lua sandbox ready.") }
    var selected by remember { mutableStateOf("Executor") }
    var saved by remember { mutableStateOf(listOf("Hello example", "Basic math")) }
    Surface(Modifier.fillMaxSize(), color = Black) {
        Column(Modifier.padding(18.dp).verticalScroll(rememberScrollState())) {
            Text("SL", color = White, fontSize = 34.sp)
            Text("ROBLOX COMPANION • SAFE LUA SANDBOX", color = Green, fontSize = 11.sp)
            Spacer(Modifier.height(16.dp))
            Button(onClick = onOverlay, colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                Text("Enable floating SL panel", color = Black)
            }
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Executor", "Saved", "Stats", "Settings").forEach {
                    FilterChip(selected == it, onClick = { selected = it },
                        label = { Text(it, color = White) })
                }
            }
            Spacer(Modifier.height(12.dp))
            when (selected) {
                "Executor" -> {
                    Text("Lua editor", color = White)
                    OutlinedTextField(value = code, onValueChange = { code = it },
                        modifier = Modifier.fillMaxWidth().height(190.dp),
                        textStyle = LocalTextStyle.current.copy(color = White),
                        label = { Text("Lua code", color = White) })
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { output = runLuaSafely(code) }) { Text("EXECUTE") }
                        OutlinedButton(onClick = {
                            saved = saved + "Script ${saved.size + 1}"
                        }) { Text("SAVE") }
                    }
                    Text("Output", color = Green)
                    Text(output, color = White)
                    Text("This runs locally in an isolated Lua sandbox. It does not execute inside Roblox.", color = White)
                }
                "Saved" -> {
                    Text("Saved scripts", color = White)
                    saved.forEach { Text("• $it", color = White, modifier = Modifier.padding(8.dp)) }
                    Text("Saved names are a starter UI; persistent script storage can be added next.", color = White)
                }
                "Stats" -> {
                    Text("Device refresh rate: shown by Android settings / device display.", color = White)
                    Text("Network ping: this app can estimate its own network latency, not Roblox game ping.", color = White)
                    Text("In-game player count and true Roblox FPS are not exposed to ordinary companion apps.", color = White)
                }
                else -> {
                    Text("Panel: black • Text: white • Accent: neon green", color = White)
                    Text("Android overlay permission is required for the floating panel.", color = White)
                    Text("No CPU/GPU overclocking: Android does not allow ordinary apps to force it.", color = White)
                }
            }
        }
    }
}

fun runLuaSafely(source: String): String {
    return try {
        val globals: Globals = JsePlatform.standardGlobals()
        val safeSource = source.take(20_000)
        globals.load(safeSource, "SL-sandbox").call().tojstring()
            .ifBlank { "Executed successfully." }
    } catch (e: Exception) {
        "Lua error: ${e.message ?: "unknown error"}"
    }
}
