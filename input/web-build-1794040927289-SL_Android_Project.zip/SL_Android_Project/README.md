# SL Android companion starter

This is a native Android Kotlin/Jetpack Compose starter for an SL companion app.

## Appearance
- Black panels by default
- White text
- Neon-green accent

## Included
- Android floating overlay panel (requires the user to grant Display over other apps permission)
- Expand/collapse and close controls
- Local LuaJ sandbox editor with Execute
- Basic Saved, Stats, and Settings screens

## Important limitations
- The Lua executor runs Lua locally inside this app only. It does **not** inject into Roblox, control Roblox, or execute scripts in a Roblox game.
- Android does not expose Roblox's exact in-game FPS, ping, or player count to ordinary companion apps. The Stats screen explains this.
- Android apps cannot force CPU/GPU overclocking or guarantee 144 FPS. Display refresh rate depends on the phone and game.
- This starter does not include or redistribute Roblox. Install Roblox from its official source.

## Build
Open this folder in Android Studio, sync Gradle, then build an APK. The overlay permission is requested by the app when you tap Enable floating SL panel.
