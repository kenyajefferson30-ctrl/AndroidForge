package com.fpsbooster.app

import android.os.Bundle
import android.content.Context
import android.hardware.display.DisplayManager
import android.view.Display
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetAddress

private val Bg = Color(0xFF080B0A)
private val Panel = Color(0xFF121916)
private val Green = Color(0xFF39F58A)
private val Muted = Color(0xFF9AA9A0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BoosterApp(this) }
    }
}

@Composable
private fun BoosterApp(context: Context) {
    var selectedTab by remember { mutableStateOf("Home") }
    var ping by remember { mutableStateOf<Long?>(null) }
    var pingState by remember { mutableStateOf("Not tested") }
    var testing by remember { mutableStateOf(false) }
    var boostEnabled by remember { mutableStateOf(false) }
    var fpsTarget by remember { mutableFloatStateOf(144f) }
    var game by remember { mutableStateOf("Roblox") }
    val refresh = remember { getRefreshRate(context) }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Green,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Green) {
                    listOf("Home", "Games", "Settings").forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = {
                                Icon(
                                    when(tab) {
                                        "Games" -> Icons.Default.SportsEsports
                                        "Settings" -> Icons.Default.Settings
                                        else -> Icons.Default.Dashboard
                                    }, contentDescription = tab
                                )
                            },
                            label = { Text(tab) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Green, selectedTextColor = Green,
                                indicatorColor = Color(0xFF20382B),
                                unselectedIconColor = Muted, unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp),
                contentPadding = PaddingValues(top = 22.dp, bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("FPS", color = Green, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("BOOSTER", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
                        }
                        Surface(color = Color(0xFF173323), shape = RoundedCornerShape(50)) {
                            Text("NO ROOT", color = Green, modifier = Modifier.padding(horizontal = 13.dp, vertical = 7.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                when (selectedTab) {
                    "Home" -> {
                        item {
                            Surface(color = Panel, shape = RoundedCornerShape(22.dp)) {
                                Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("PERFORMANCE MODE", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.height(12.dp))
                                    Text(if (boostEnabled) "OPTIMIZATION ON" else "READY TO OPTIMIZE", color = Green, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                                    Spacer(Modifier.height(15.dp))
                                    Button(
                                        onClick = { boostEnabled = !boostEnabled },
                                        colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.Black),
                                        modifier = Modifier.fillMaxWidth().height(58.dp),
                                        shape = RoundedCornerShape(16.dp)
                                    ) {
                                        Icon(Icons.Default.Bolt, contentDescription = null)
                                        Spacer(Modifier.width(8.dp))
                                        Text(if (boostEnabled) "TURN OFF PROFILE" else "ACTIVATE PROFILE", fontWeight = FontWeight.Black)
                                    }
                                    Spacer(Modifier.height(10.dp))
                                    Text(
                                        if (boostEnabled) "Profile active. Android limits which system settings third-party apps can change."
                                        else "Activates this app's game profile and monitoring tools.",
                                        color = Muted, fontSize = 11.sp
                                    )
                                }
                            }
                        }
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                MetricCard("DISPLAY RATE", "${refresh.toInt()} Hz", "Device display mode", Modifier.weight(1f))
                                MetricCard("PING", ping?.let { "$it ms" } ?: "--", pingState, Modifier.weight(1f))
                            }
                        }
                        item {
                            Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
                                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                                    Text("NETWORK LATENCY TEST", color = Green, fontWeight = FontWeight.Bold)
                                    Text("Measures reachability to 1.1.1.1. This is not your game's server ping.", color = Muted, fontSize = 12.sp)
                                    Spacer(Modifier.height(12.dp))
                                    Button(
                                        enabled = !testing,
                                        onClick = {
                                            testing = true
                                            pingState = "Testing…"
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.Black)
                                    ) { Text(if (testing) "TESTING…" else "TEST CONNECTION") }
                                    LaunchedEffect(testing) {
                                        if (testing) {
                                            val result = withContext(Dispatchers.IO) {
                                                try {
                                                    val start = System.nanoTime()
                                                    val reachable = InetAddress.getByName("1.1.1.1").isReachable(2500)
                                                    val elapsed = (System.nanoTime() - start) / 1_000_000
                                                    if (reachable) elapsed else null
                                                } catch (_: Exception) { null }
                                            }
                                            ping = result
                                            pingState = if (result == null) "No response (ICMP may be blocked)" else "Round-trip estimate"
                                            testing = false
                                        }
                                    }
                                }
                            }
                        }
                        item {
                            Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
                                Column(Modifier.padding(18.dp)) {
                                    Text("SELECTED GAME", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Text(game, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    Text("Profiles do not modify game files or bypass game restrictions.", color = Muted, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                    "Games" -> {
                        item { Text("YOUR GAMES", color = Green, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                        item {
                            listOf("Roblox", "PUBG Mobile", "Call of Duty: Mobile", "Free Fire", "Minecraft", "Other game").forEach { name ->
                                Card(
                                    onClick = { game = name; selectedTab = "Home" },
                                    colors = CardDefaults.cardColors(containerColor = Panel),
                                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                                ) {
                                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.SportsEsports, tint = Green, contentDescription = null)
                                        Spacer(Modifier.width(12.dp))
                                        Text(name, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                                        if (game == name) Icon(Icons.Default.CheckCircle, tint = Green, contentDescription = "Selected")
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        item { Text("PERFORMANCE SETTINGS", color = Green, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                        item {
                            Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
                                Column(Modifier.padding(18.dp)) {
                                    Text("FPS / REFRESH-RATE TARGET", fontWeight = FontWeight.Bold)
                                    Text("${fpsTarget.toInt()} FPS target", color = Green, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                                    Slider(
                                        value = fpsTarget,
                                        onValueChange = { fpsTarget = it },
                                        valueRange = 30f..144f,
                                        steps = 3,
                                        colors = SliderDefaults.colors(thumbColor = Green, activeTrackColor = Green)
                                    )
                                    Text("A target is a preference, not a forced game frame rate. Actual FPS depends on the phone, display, and game.", color = Muted, fontSize = 12.sp)
                                }
                            }
                        }
                        item {
                            Surface(color = Panel, shape = RoundedCornerShape(18.dp)) {
                                Column(Modifier.padding(18.dp)) {
                                    Text("WHAT THIS APP CAN CONTROL", color = Green, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.height(8.dp))
                                    Text("• Monitor the device display refresh rate\n• Run a basic network reachability test\n• Save a selected game and FPS target\n• Provide a one-tap profile state", color = Color.White, lineHeight = 24.sp)
                                    Spacer(Modifier.height(8.dp))
                                    Text("Android does not allow an ordinary app to overclock CPU/GPU, force another app's FPS, or guarantee lower game ping.", color = Muted, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
                item {
                    Text("FPS BOOSTER  •  VERSION 1.0", color = Muted, fontSize = 10.sp, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, subtitle: String, modifier: Modifier = Modifier) {
    Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = modifier) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(value, color = Green, fontSize = 25.sp, fontWeight = FontWeight.Black)
            Text(subtitle, color = Muted, fontSize = 10.sp)
        }
    }
}

private fun getRefreshRate(context: Context): Float {
    val manager = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    val display = manager.getDisplay(Display.DEFAULT_DISPLAY)
    return display?.refreshRate ?: 60f
}
