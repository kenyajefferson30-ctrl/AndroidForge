# FPS BOOSTER (Android / Kotlin)

Native Android Studio starter project using Kotlin and Jetpack Compose.

## Open and run
1. Install Android Studio (latest stable).
2. Open this folder in Android Studio.
3. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Select **Run**.

## Included in this starter
- Black + neon green Compose interface.
- Home, Games, and Settings tabs.
- 144 FPS preference slider (a target/preference, not a forced game FPS).
- Device display refresh-rate readout.
- Basic reachability/latency test to 1.1.1.1.
- Game selection including Roblox and other popular games.
- Local in-memory profile toggle.

## Important Android limitations
This no-root app does not overclock CPU/GPU, change another app's internal frame-rate cap, read another game's live FPS, or guarantee ping/lag improvements. Android restricts third-party apps from controlling those resources. Display refresh rate is not the same as in-game FPS. The network test is a basic reachability estimate; ICMP may be blocked and game-server latency will differ.

This is a starter project, not a compiled or signed APK. Build it in Android Studio and test on your device before distributing.
